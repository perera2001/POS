package com.example.pos.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PosAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PosAppApplication.class, args);
	}

}
