package com.example.pos.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PosAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
